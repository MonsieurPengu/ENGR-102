# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name: 		Brock Balthazor
# Section:		510
# Assignment:	Lab3
# Date:		18 Sept 2018
pounds = float(input("number of pounds "))
Newtons = pounds*4.448
print(Newtons, "Newtons")
