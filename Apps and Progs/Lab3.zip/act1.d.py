SPR = float(input("Number of seconds per revolution "))
Hertz = 1/(SPR*1/360)
print(Hertz, "Hertz")
