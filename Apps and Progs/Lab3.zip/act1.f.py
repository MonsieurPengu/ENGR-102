F = float(input("Degrees in Fahrenheit "))
C = (F-32)/(9/5)
print(C, "Degrees Celsius")
