Pascals = float(input("Number of Pascals "))
MMmerc = Pascals/133.322387415
print(MMmerc, "millimeters of Mercury")
