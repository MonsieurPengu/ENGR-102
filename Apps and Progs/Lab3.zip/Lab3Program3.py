#Ian Wang
#Section C11
#227004716

Name = str(input("What is your name? "))
City = str(input("What city are you from? "))
Color = str(input("What is your favorite color? "))
Team = str(input("What is your favorite sports team? "))
Age = str(input("How young are you? "))
Number = str(input("What is your favorite number? "))

print("Origins \n \t There once was a ,", Age, "year old lil boi named", Name, ". \n He lived in the city of", City, "for most of his life, and always called it the \'Best City\'", ". \n He adored the color that is", Color, "and would wear", Color, "everyday, along with the number", Number, "and a", Team, "logo because he'd be willing to \"sell away his soul\"", "for these and had very deep, intimate feelings for them. \nThey were unrequited, however very passionate and warm... and... \nsucculent.")


