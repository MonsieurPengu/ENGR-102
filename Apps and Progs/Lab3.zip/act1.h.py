RV1 = float(input("Richter Scale Value 1 "))
RV2 = float(input("Richter Scale Value 2 "))
Energy1 = 10**((1.5*RV1)+4.8)
Energy2 = 10**((1.5*RV2)+4.8)
ERatio = Energy1/Energy2
print(ERatio)
