MPH = float(input("Miles per Hour "))
MPS = MPH*1609.344/3600
print(MPS, "Meters per second")
