BTU = float(input("Number of BTUs "))
Joules = BTU*1055.05585262
print(Joules, "Joules")
